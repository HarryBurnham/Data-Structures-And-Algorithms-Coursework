package main;

import lib.Mentors;

public class MentorsApp {

	public static void main(String[] args) {
		//create a new mentor object
		Mentors m = new Mentors();
		
		//add all mentors
		m.addMentor("P2531111");
		m.addMentor("P2531120");
		m.addMentor("P2532211");
		m.addMentor("P2534141");
		m.addMentor("P2530001");
		
		//add all mentees
		m.addMentee("P2531120");
		m.addMentee("P2532211");
		m.addMentee("P2530201");
		m.addMentee("P2530150");
		m.addMentee("P2530190");
		m.addMentee("P2530210");
		m.addMentee("P2530229");
		m.addMentee("P2530250");
		m.addMentee("P2530230");
		m.addMentee("P2534141");
		
		//sets all mentors for all the mentees
		m.setMentor("P2531111", "P2531120");
		m.setMentor("P2531111", "P2532211");
		m.setMentor("P2531120", "P2530201");
		m.setMentor("P2532211", "P2530150");
		m.setMentor("P2532211", "P2530190");
		m.setMentor("P2532211", "P2530210");
		m.setMentor("P2534141", "P2530229");
		m.setMentor("P2534141", "P2530250");
		m.setMentor("P2530001", "P2530230");
		m.setMentor("P2530001", "P2534141");
		
		//outputs mentee array
		System.out.println(m.getMentees());
		
		//output mentors array
		System.out.println(m.getMentors());
		System.out.println("");
		
		//prints adjacency matrix 
		m.printMatrix();
		System.out.println("");
		
		//finds a mentee of a specific mentor based on the mentors p number, should be P2531120
		System.out.println(m.getMentee("P2531111"));
		System.out.println("");
		
		//finds a mentor of a specific mentee based on the mentees p number, should output P2532211
		System.out.println(m.getMentor("P2530150"));
		System.out.println("");
		
		//search if a mentee is in the array,should output true
		System.out.println(m.searchMentee("P2532211"));
		System.out.println("");
		
		//search if a mentor is in the array ,should output true
		System.out.println(m.searchMentor("P2530001"));
		System.out.println("");
		
		//finds index of mentee, one the index, one -1 to show both work
		System.out.println(m.indexOfMentee("P2530230"));
		System.out.println(m.indexOfMentee("P0000000"));
		System.out.println("");
		
		//finds index of mentor, one the index, one -1 to show both work
		System.out.println(m.indexOfMentor("P2532211"));
		System.out.println(m.indexOfMentor("P0000000"));
		System.out.println("");
		
		//checks whether two objects are equals should output false then true
		System.out.println(m.equals(5));
		System.out.println(m.equals(m));
		System.out.println("");
		
		//creates a new mentor object
		Mentors n = new Mentors();
		
		n.addMentor("P2300");
		n.addMentee("P5400");
		//checks whether the two objects are equal should return false 
		System.out.println(m.equals(n));
		System.out.println("");
		
		//prints all mentees for a given mentor, expected answers are P2530150, P2530190,P2530210
		m.findAllMentees("P2532211");
		System.out.println("");
		
		//remove a mentee then print the mentees array out again
				m.removeMentee("P2530210");
				System.out.println(m.getMentees());
				System.out.println("");
				
				//print out the values of the adjacency matrix after removing an element
				m.printMatrix();
				System.out.println("");
		
				
	}

}

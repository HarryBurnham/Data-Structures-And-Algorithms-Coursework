package lib;

import java.util.Arrays;

public class Mentors {

	private boolean[][]matrix; // create an adjacency matrix
	private String mentors[]; // create an array of mentors
	private String mentees[]; // create an array of mentees
	private int numberOfMentees; // the number of mentees
	private int numberOfMentors; // the number of mentors

	public Mentors() {
		numberOfMentees = 0; //Initialises the number of mentees as 0
		numberOfMentors = 0; //Initialises the number of mentors as 0
		mentees= new String[numberOfMentees]; //creates an array of mentees the size of the number of mentees
		mentors = new String[numberOfMentors]; //creates an array of mentors the size of the number of mentors
		matrix = new boolean[numberOfMentors][numberOfMentees]; // creates an adjacency matrix the size of the number of mentors by the number of mentees
	}

	// add a mentee to the array
	public void addMentee(String mentee) {

		int newNumberOfMentees = numberOfMentees +1; //adds 1 to the number of mentees and stores it in a new variable
		String newMentees[] = new String[newNumberOfMentees]; // Initialises a new array of strings that is one bigger in size
		boolean[][] newMatrix = new boolean[numberOfMentors][newNumberOfMentees]; // creates an adjacency matrix that is one column bigger

		//for loop for each mentor
		for(int i=0;i<numberOfMentors;i++) {
			//for loop for each mentee including the new one
			for (int j=0;j<newNumberOfMentees;j++) {
				if (j<numberOfMentees) {             //when j is less then the number of mentees it is referring to all the previous ones that exist
					newMentees[j] = mentees[j];             //populates the array and matrix using a for loop so the new mentee is added to both
					newMatrix[i][j]=matrix[i][j];
				}else {
					newMentees[j] = mentee;
					newMatrix[i][j] = false;  //adds the new mentee in to the array and sets it to false so no mentor is set
				}
			}
		}
		numberOfMentees++;
		matrix = newMatrix;  // changes the number of mentees, the adjacency matrix and the mentees array permanently so that more mentees may be added or removed
		mentees = newMentees;
	}

	//same as addMentee
	public void addMentor(String mentor) {

		int newNumberOfMentors = numberOfMentors +1;
		String newMentors[] = new String[newNumberOfMentors];
		boolean[][] newMatrix = new boolean[newNumberOfMentors][numberOfMentees];

		for(int i=0;i<newNumberOfMentors;i++) {

			if (i<numberOfMentors) {
				newMentors[i] = mentors[i];
				newMatrix[i]=matrix[i];
			}else {
				newMentors[i] = mentor;
				newMatrix[i] = new boolean[numberOfMentees];
			}
		}
		numberOfMentors++;
		matrix = newMatrix;
		mentors = newMentors;
	}

	//takes string of mentor and mentee and sets it to true 
	public void setMentor(String mentor, String mentee){
		int mentorTemp = indexOfMentor(mentor);
		int menteeTemp = indexOfMentee(mentee);

		matrix[mentorTemp][menteeTemp] = true; //sets a new mentor for the mentee based on the two inputs 
	}

	//returns the mentees array
	public String getMentees(){
		return Arrays.toString(mentees);

	}

	//returns the mentors array
	public String getMentors() {
		return Arrays.toString(mentors);
	}

	//finds a specific mentee based on their mentor's number
	public String getMentee(String mentor){

		int mentorNumber = indexOfMentor(mentor);

		for (int j=0;j<numberOfMentors;j++) { 
			if (matrix[mentorNumber][j] == true) { //searches the adjacency matrix for the index of the mentee based on mentor number
				return mentees[j]; //returns the correct mentor 
			}
		}

		return "not found"; //if the mentor number is not found or the mentee is not a mentee of the mentor then returns false 
	}

	//finds a specific mentor based on a mentee number
	public String getMentor(String mentee){

		int menteeNumber = indexOfMentee(mentee);


		for (int j=0;j<numberOfMentees;j++) {
			if (matrix[j][menteeNumber] == true) { //searches the adjacency matrix for the index of the mentor based on the mentee number 
				return mentors[j]; //returns the correct mentor 
			}
		}
		return "not found"; // if the mentee number is not found or the mentor is not a mentor of the mentee then returns false 
	}

	// finds if a mentee exists and if they have a mentor and returns whether the mentee was found and if found whether or not they have a mentor
	public boolean searchMentee(String mentee){
		for (int i=0;i<numberOfMentees;i++) { //goes through the whole of the for loop which is the size of the array
			if (mentees[i].equals(mentee)){ //checks whether the mentee is in the array and if it is 
				return true; //returns true 
			}
		}
		return false; //else returns false (only after the whole for loop has finished)
	}

	//finds whether a mentor exists and returns whether or not the data entered is a mentor or not
	public boolean searchMentor(String mentor){
		for (int i=0; i< numberOfMentors;i++) { // goes though whole of for loop which is the size of the array 
			if(mentors[i].equals(mentor)) { // checks whether the mentor is in the array then if it is 
				return true; //returns true
			}
		}
		return false; //else returns false (only after the whole loop has finished)
	}

	//finds the index of a specific mentee in the array
	public int indexOfMentee(String mentee){
		for (int i=0; i<numberOfMentees;i++) {
			if(mentees[i].equals(mentee)) {
				return i; //returns the index of where in the array the mentee is 
			}
		}
		return -1; // returns -1 if the mentee is not in the array (after the for loop has gone through all the mentees)
	}

	//finds the index of a specific mentor in the array
	public int indexOfMentor(String mentor){	
		for (int i=0; i<numberOfMentors;i++) {
			if(mentors[i].equals(mentor)) {
				return i; //returns the index of where in the array the mentor is 
			}
		}
		return -1; //returns -1 if the mentor is not in the array (after the for loop has gone through all the mentors)
	}

	//find all mentees for a given mentor
	public void findAllMentees(String mentor) {
		int index =indexOfMentor(mentor); //finds index of mentor

		for (int i=0;i<numberOfMentees;i++) { //loops through all mentees
			if (matrix[index][i]== true) { //if true then that means that mentor is a mentor for the mentee at index i
				System.out.println(mentees[i]); //output corresponding mentee
			}
		}
	}

	//removes a mentee from the arrays
	public void removeMentee(String mentee) {

		int newNumberOfMentees = numberOfMentees -1; // minuses 1 from the number of mentees
		String newMentees[] = new String[newNumberOfMentees]; //initialises a new array of Strings 1 smaller then before
		boolean[][] newMatrix = new boolean[numberOfMentors][newNumberOfMentees]; //initialises a new adjacency matrix with one smaller column

		int index= indexOfMentee(mentee); // gets index of mentee
		int change = 0;


		for (int i=0;i<numberOfMentors;i++) {
			for(int j=0;j<newNumberOfMentees;j++) {
				if(j==index) {
					change = 1;

				} 
					newMentees[j] = mentees[j + change];  
					newMatrix[i][j] = matrix[i][j + change];
			}
		}
		numberOfMentees--; 
		matrix = newMatrix;  // changes the number of mentees, the adjacency matrix and the mentees array permanently so that more mentees may be added or removed 
		mentees = newMentees;
	}

	public void printMatrix() {
		for (int i=0; i<numberOfMentors;i++) {
			for (int j=0;j<numberOfMentees;j++) {
				System.out.println(matrix[i][j]);
			}
		}
	}

	//checks whether two objects are the same 
	@Override
	public boolean equals(Object obj){
		if (obj == null || this.getClass() != obj.getClass()) {
			return false;
		}

		Mentors other = (Mentors) obj; //creates a new object

		return this.mentors.equals(other.mentors) &&  //checks if the two mentor arrays are identical for both objects
				this.mentees.equals(other.mentees) &&  //checks if the two mentee arrays are identical for both objects 
				this.numberOfMentees == other.numberOfMentees&& //checks if the number of mentees of both objects are identical
				this.numberOfMentors == other.numberOfMentors;

	}

}
